// // routes/barcodeRoutes.js
// const express = require('express');
// const router = express.Router();
// const { generateAndStoreBarcodes } = require('../Controller/barcodeController');

// router.get('/barcodes', generateAndStoreBarcodes);

// module.exports = router;